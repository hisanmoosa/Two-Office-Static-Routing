# Project 6 — Two Office Static Routing
Connect Dublin and Cork LANs using two routers and manually configured routes.

## Files
- topology/: supplied Packet Tracer project and cabling plan
- screenshots/: original topology screenshot and combined JPG
- configurations/: separate router configuration transcriptions and reference build commands
- addressing/: IP table
- verification/: route entries, supplied tests, traceroute, source hash
- documentation/: simple explanation, actual corrections and practice troubleshooting

Open topology/Project-6-Two-Office-Static-Routing.pkt in Cisco Packet Tracer. Text/Markdown files open in any text editor.

## Verified from supplied evidence
Both static routes appear in the router tables. Router-link repeat ping returned 5/5. Cork-to-Dublin PC ping returned 4/4 with 0% loss. Dublin-to-Cork PC ping and both local gateway pings were reported successful by the learner. Dublin-to-Cork traceroute reached the destination through two routers.

## Evidence limits
The original .pkt and screenshot bytes are preserved unchanged. The .pkt was not independently executed or internally inspected. Combined JPG panels recreate supplied text; they are not original CLI screenshots. Repeated empty separators are omitted from running-config transcriptions; all supplied configuration statements are retained. Route excerpts omit legends/grouping. Reference build commands are not raw transcripts. The learner-reported tests without full output are labelled accordingly. This package covers Project 6 only.
