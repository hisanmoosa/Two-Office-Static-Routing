# Project 6 — Two-office static routing
A static route is a route added manually. A router automatically knows its directly connected networks, but needs a route for the other office's subnet.

Dublin routes 192.168.20.0/24 via 10.0.0.2. Cork routes 192.168.10.0/24 via 10.0.0.1. Both directions are needed for successful requests and replies in this design.

The route destination is the whole network, such as 192.168.20.0/24. It is not the Cork gateway 192.168.20.1. Dublin's next hop is 10.0.0.2: the adjacent Cork interface reachable on the router link.

The router link uses 10.0.0.0/30 (255.255.255.252). Its usable addresses are .1 and .2; .0 is the network address and .3 the broadcast address. This is a separate subnet from both office LANs.

C means connected; L means the router's own address; S means static. [1/0] is administrative distance 1 and metric 0. No default route is required for these explicitly routed networks.

Ping checks replies, timing and loss. Tracert shows the path. The supplied trace shows Dublin gateway, Cork router, then CORK-PC: two routers and one destination. The TTL=126 ping replies are consistent with two router hops from the usual Packet Tracer PC starting TTL of 128.

## Actual corrections during the lab
The learner initially reported entering Cork's LAN IP on G0/1. That address was removed. Intermediate Cork output then showed G0/0 using 192.168.10.1; this was corrected to 192.168.20.1. G0/1 was later assigned 10.0.0.2/30. The supplied final running-config confirms both final addresses.

## Troubleshooting practice (discussion only)
If Dublin reaches its gateway but not Cork-PC: check router interface status, ping 10.0.0.2 and inspect Dublin's static route. On Cork, check interfaces, ping 10.0.0.1, inspect the return route, and check CORK-PC's address/mask/gateway. No return-route fault was injected into the saved project.

## Scope
This is a simulated office-to-office routed link. No ISP, real leased line, VPN encryption, dynamic routing, NAT, ACL or internet access was configured. Router configs contain no enable secret or SSH setup. Switch running-config exports were not supplied.
